const example = 'some string'

console.log(example)