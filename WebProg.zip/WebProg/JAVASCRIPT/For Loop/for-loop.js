var total = 0;

var limit = 10;

for (var i = 0; i < limit; i++) {
  total += i;
}

console.log(total);
